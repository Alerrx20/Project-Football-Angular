package ale.atos.apiFootball;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFootballApplicationTests {

	@Test
	void contextLoads() {
	}

}
