export class Team {
    id!: number;
    name!: string;
    acronym!: string;
}