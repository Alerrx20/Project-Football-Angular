export interface Credentials {
    email: String;
    password: String;
}